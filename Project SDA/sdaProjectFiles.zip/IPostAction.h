#pragma once
#include "IApplication.h"
class IPostAction {
public:
	virtual void postaction() = 0;
};
