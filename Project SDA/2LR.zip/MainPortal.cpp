#pragma once
#include "MainPortal.h"

MainPortal* MainPortal::main = nullptr;

