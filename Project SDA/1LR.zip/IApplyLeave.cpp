#pragma once

#include "IApplyLeave.h"
IApplyLeave* IApplyLeave::main = nullptr;
