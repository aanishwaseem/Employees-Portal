#pragma once
#include "Main.h"

Main* Main::main = nullptr;
