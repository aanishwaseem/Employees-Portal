#pragma once

#include "NotificationManager.h"
NotificationManager* NotificationManager::instance = nullptr;
